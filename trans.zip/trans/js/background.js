chrome.extension.onRequest.addListener(function (request, sender, sendResponse) {
    console.log('request', request);
    console.log('sender', sender);
    if (request.action == 'trans') {
        var appid = '20151211000007653';
        var key = 'IFJB6jBORFuMmVGDRude';
        var salt = (new Date).getTime();
        var str1 = appid + request.word + salt + key;
        var sign = MD5(str1);
        $.ajax({
            url: 'http://api.fanyi.baidu.com/api/trans/vip/translate',
            method: 'GET',
            data: {
                q: request.word,
                appid: appid,
                salt: salt,
                from: 'auto',
                to: 'zh',
                sign: sign
            },
            asyne: true
        }).done(function (data) {
            // console.log('transData', data);
            sendResponse({
                data: data
            });
        });
    }else {
        //todo
    }
});