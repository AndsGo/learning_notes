//获取btnTrans按钮
var btnBuildTest = document.getElementById("btnTrans");
//绑定点击事件，发送请求
btnBuildTest.onclick = function () {
    var word = document.getElementById("query").value
    if(word){
        chrome.extension.sendRequest({
            action: "trans",
            word: word
        },
        function(f) {
          if(f.data&&f.data.trans_result){
            //将翻译结果显示在result中
            document.getElementById("result").value = f.data.trans_result[0].dst
          }
        });
    }
}
